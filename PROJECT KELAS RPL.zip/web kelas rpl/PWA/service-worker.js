const CACHE_NAME = "fx-intelligence-cache-v2";
const urlsToCache = [
  "/",
  "/index.html",
  "/manifest.json",
  "/style/style.css",
  "/script/script.js",
  "/img/logo-10rpl.jpg"
];

self.addEventListener("install", (event) => {
  console.log("📦 Service Worker installing...");
  self.skipWaiting();

  event.waitUntil(
    caches.open(CACHE_NAME).then(async (cache) => {
      console.log("📥 Mulai cache file satu per satu...");
      for (const url of urlsToCache) {
        try {
          const response = await fetch(url);
          if (!response.ok) {
            throw new Error(`Status ${response.status}`);
          }
          await cache.put(url, response.clone());
          console.log(`✅ Cached: ${url}`);
        } catch (err) {
          console.warn(`⚠️ Gagal cache ${url}:`, err.message);
        }
      }
    })
  );
});

self.addEventListener("activate", (event) => {
  console.log("🔁 Activating Service Worker...");
  event.waitUntil(
    caches.keys().then((cacheNames) =>
      Promise.all(
        cacheNames.map((cache) => {
          if (cache !== CACHE_NAME) {
            console.log("🗑️ Menghapus cache lama:", cache);
            return caches.delete(cache);
          }
        })
      )
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (event) => {
  event.respondWith(
    caches.match(event.request).then((cachedResponse) => {
      return (
        cachedResponse ||
        fetch(event.request).catch(() => caches.match("/index.html"))
      );
    })
  );
});
